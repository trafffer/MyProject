package bg.softuni.homerestate.models.entities.enums;

public enum UserRole {
    ADMIN, USER
}
