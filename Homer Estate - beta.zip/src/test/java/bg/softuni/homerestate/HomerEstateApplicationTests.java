package bg.softuni.homerestate;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomerEstateApplicationTests {

}
